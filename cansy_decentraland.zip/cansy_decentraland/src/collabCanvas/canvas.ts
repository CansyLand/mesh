import { Pixel, PixelData } from "./pixel"
import { Timer } from "./timer"
import { Session } from "../server/session"
import { fetchPixelHistory } from "../server/server"
import { sceneMessageBus } from "./messageBus"
import { ArtistList } from "./artistList"
import { setTimeout } from "@dcl/ecs-scene-utils"
// import * as utils from '@dcl/ecs-scene-utils'


export class Canvas extends Entity {
    pixelMatrix: Pixel[][] = []
    artistList: ArtistList

    constructor(width: number, height: number, timer: Timer, artistList: ArtistList) {
        super()

        this.initCanvas(width, height, timer)
        this.artistList = artistList

        sceneMessageBus.on("NewPixel", (pixel: PixelData) => {
            this.drawPixel(
                pixel.x,
                pixel.y,
                pixel.color
                )
                this.artistList.addNewPixel(pixel)
          }) 
    }

    private initCanvas(x: number, y: number, timer: Timer) {
        this.pixelMatrix = [];

        // using the same mesh reduces computational load
        const planeShape = new PlaneShape()
      
        for (let i = 0; i < x; i++) {
          const row: Pixel[] = [];
          
          for (let j = 0; j < y; j++) {
            const newPixel = new Pixel(planeShape,i, j, timer);
            newPixel.setParent(this);
            row.push(newPixel);
          }
          
          this.pixelMatrix.push(row);
        }
      }
      

    async drawPixelHistory() {
        const sessionInstance = Session.getInstance()
        const realm = await sessionInstance.getRealm()
        const pixelHistory: PixelData[] = await fetchPixelHistory(realm?.displayName as string, 169)

        // Define the delay between painting each pixel
        const delay = 10; // milliseconds

        

            
        // Sort pixel history by time
        pixelHistory.sort((a, b) => a.timestamp["_seconds"] - b.timestamp["_seconds"]);

        // Iterate over the pixel history with a delay between each pixel
        for (let index = pixelHistory.length - 1; index >= 0; index--) {
            const pixelData = pixelHistory[index] 
            setTimeout(delay * index, ()=>{
                this.drawPixel(pixelData.x, pixelData.y, pixelData.color)
            })
        }
        

        // pixelHistory.forEach(async pixelData => {
        //     // this.drawPixel(pixelData.x, pixelData.y, pixelData.color)
       
        //     await this.drawPixelDelayed(pixelData.x, pixelData.y, pixelData.color, delay);
        // })

        // update ArtistList
        this.artistList.updateListByPixelHistory(pixelHistory)
    }


    // drawPixelDelayed(x: number, y: number, color: string, delay: number): Promise<void> {
    //     return new Promise((resolve) => {
    //       setTimeout(delay ,() => {
    //         this.drawPixel(x, y, color);
    //         resolve();
    //       });
    //     });
    // }

    drawPixel(x:number, y:number, color:string) {
        const pixel: Pixel | undefined = this.getPixel(x, y)
        if (pixel) {
            pixel.setColor(color)
        }
    }

    // Method to get a pixel by coordinates
    getPixel(x: number, y: number): Pixel | undefined {
        if (this.pixelMatrix[x]?.[y]) {
            return this.pixelMatrix[x][y];
        }
        return undefined;
    }
}


// class CanvasSystem implements ISystem {
//     canvas: Canvas

//     constructor(canvasEntity: Canvas) {
//         this.canvas = canvasEntity
//     }

//     update(dt: number) {   
//         if(this.canvas.active) {
//             this.canvas.seconds -= dt
//             this.canvas.drawNextPixel()
//         }
//       }
// }