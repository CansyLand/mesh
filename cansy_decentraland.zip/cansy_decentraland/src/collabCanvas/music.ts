import { materialManager } from "./materialManager"

export class Music extends Entity {
    source: AudioSource
    text: TextShape
    onOff: boolean = true
  
    constructor() {
      super()
      const music: AudioClip = new AudioClip("audio/soundtrack.mp3")
      this.source = new AudioSource(music)
      this.addComponent(this.source)
      this.source.playing = true
      this.source.loop = true
      this.source.volume = 0

      engine.addSystem(new PlayersPosition(this.source, this))


      const box = new Entity()
      box.setParent(this)
        box.addComponent(new BoxShape())
        const material = materialManager.getMaterialByName("black");
        box.addComponent(material)
        box.addComponent(new Transform({
            position: new Vector3(0,0,0.1),
            scale: new Vector3(0.5,0.3,0.05)
            ,}))

        this.text = new TextShape("music")
        this.text.fontSize = 1
        this.text.hTextAlign = 'center'
        this.text.opacity = 0.2
        this.addComponent(this.text)

         // on hover
         box.addComponent(
            new OnPointerHoverEnter(() => {
                this.text.opacity = 1
            })
        )

        // on hover exit
        box.addComponent(
            new OnPointerHoverExit(() => {
                this.text.opacity = 0.2
            })
        )

        // on click
        box.addComponent(
            new OnPointerDown(() => {
                this.onOff = !this.onOff
            })
        )
    }
  
  }


  class PlayersPosition implements ISystem {
    music: AudioSource
    m: Music
    playing: boolean = false
    constructor(music: AudioSource, m: Music) {
        this.music = music
        this.m = m
    }

    update(dt: number) {  
        // If player is above 7m play music
        
        if(Camera.instance.feetPosition.y > 7 ) {
            if(this.m.onOff) {
                this.music.volume = 0.2
            } else {
                this.music.volume = 0
            }
                
        } else {
                this.music.volume = 0
            
        }
      }
}