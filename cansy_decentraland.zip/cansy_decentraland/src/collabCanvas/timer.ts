import * as ui from '@dcl/ui-scene-utils'
import { Audio } from './audio'

export class Timer extends Entity {
    time: number = 0
    active: boolean = false
    seconds: number = 0
    previousSecond: number = 0
    totalCooldown: number = 0
    audioOn: boolean = true
    cooldown: ui.CornerLabel
    bar: ui.UIBar
    audio: Audio

    // loudClickAudio: AudioClip = 
    //     new AudioClip("audio/click_bright_001.mp3")

    // silentClickAudio: AudioClip = 
    //     new AudioClip("audio/click_bright_002.mp3")

    constructor() {
        super()

        this.audio = Audio.getInstance()

        engine.addSystem(new TimerSystem(this))


        // cooldown bar
        this.bar = new ui.UIBar(1, -30, 0, Color4.Yellow(), ui.BarStyles.ROUNDSILVER, 3)
        this.bar.bar.hAlign = 'right'
        this.bar.bar.positionX = -5
        this.bar.bar.height = 10
        this.bar.background.height = 20
        this.bar.hide()



        this.cooldown = new ui.CornerLabel('', -50, 30, undefined, 40)
        

        
    }

    start(time:number) {  
        if (time > 0) {
            this.setSeconds(time)
            this.active = true
            this.bar.show()
            this.audio.playLoudClick()
        }
    }

    startMilliseconds(milliseconds:number) {
        this.start(milliseconds/1000)
    }

    setSeconds(seconds: number): void {
        this.seconds = seconds
        this.previousSecond = seconds
        this.totalCooldown = seconds
        this.updateDisplay()
        this.updateBar()
    }

    updateDisplay() {
        const minute = Math.floor(this.previousSecond / 60)
        const second = this.previousSecond % 60
        this.cooldown.set(this.padNumber(minute) + ":" + this.padNumber(second))
        
        if(this.seconds < 3) {
            this.audio.playClockClick()
        }

    }

    updateBar() {
        const progress = this.seconds / this.totalCooldown;
        this.bar.set(progress)
    }

    updateCounter() {
        const currentSecond = Math.floor(this.seconds)
        // making sure updateDisplay() is only caled once a second 
        if( this.previousSecond > currentSecond ) {
            this.previousSecond = currentSecond
            this.updateDisplay()
            if( currentSecond <= 0) {
                this.active = false
                this.bar.hide()
                this.cooldown.set("")
                this.audio.playLightPing()
                log("Cooldown finished!")
            }
        }
    }

    // ads zero 8 -> 08
    private padNumber(number: number): string {
        if(number < 10) 
            return "0" + number
        return "" + number
    }

}


class TimerSystem implements ISystem {
    timer: Timer

    constructor(timerEntity: Timer) {
        this.timer = timerEntity
    }

    update(dt: number) {   
        if(this.timer.active) {
            this.timer.seconds -= dt
            this.timer.updateCounter()
            this.timer.updateBar()
        }
      }
}