import { materialManager } from "./materialManager"
import * as utils from '@dcl/ecs-scene-utils'
import { Audio } from './audio'


/**
 *  This is the button with which the player chooses the color to paint with 
 * 
 */

export class ColorPicker extends Entity {
    color: string = 'white'
    audio: Audio = Audio.getInstance()
    idlePosition: Vector3
    activePosition: Vector3
    clickPosition: Vector3

    constructor(color: string, x: number, y: number) {
        super()
        

        const material = materialManager.getMaterialByName(color);

        if(materialManager.colorExist(color))
            this.color = color

         this.addComponent(material)

         this.idlePosition = new Vector3(x, y, 0) 
         this.activePosition = new Vector3(x, y, 0.5)
         this.clickPosition = new Vector3(x, y, -0.25)
         // add a transform to the entity
         this.addComponent(new Transform({ position: this.idlePosition}))

         // add a shape to the entity
         this.addComponent(new BoxShape())

         // add the entity to the engine
         // engine.addEntity(this)

         this.addComponent(  
            new OnPointerDown(() => {
                // return color
                materialManager.setActiveColor(this.color)
                this.audio.playSilentClick()
                this.addComponentOrReplace(
                    new utils.MoveTransformComponent(this.activePosition,this.clickPosition, 0.1)
                )
            })
         )

         this.addComponent(
            new OnPointerHoverEnter(() => {
                this.audio.playLoudClick()
                // Move x by 0.1
                this.addComponentOrReplace(
                    new utils.MoveTransformComponent(this.idlePosition,this.activePosition, 0.25)
                );
            })
        );
        
        this.addComponent(
            new OnPointerHoverExit(() => {
                // Move x back to original position
                this.addComponentOrReplace(
                    new utils.MoveTransformComponent(this.activePosition,this.idlePosition, 0.5)
                );
            })
        );
    }
}