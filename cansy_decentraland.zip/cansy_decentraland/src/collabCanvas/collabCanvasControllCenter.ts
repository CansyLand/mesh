import { Canvas } from "./canvas"
import { ColorPickerBoard } from "./colorPickerBoard"
import { Timer } from "./timer"
import { fetchCooldownTimer, sendDrawPixelRequest, fetchPixelHistory } from "../server/server"
import { ArtistList } from "./artistList"
import { MeshCube } from "./meshCube"
import { InfoBox } from "./infoBox"
import { Music } from "./music"

export class CollabCanvasControllCenter extends Entity {

    timer: Timer
    canvas: Canvas

    constructor() {
        super()

        const OFFSET = 8
        const OFFSET_Z = -1

        // MESH CUBE
        const meshCube = new MeshCube()
        meshCube.addComponent(new Transform({
            position: new Vector3(0,-0.3,0),
          }))
        meshCube.setParent(this)

        // Timer
        this.timer = new Timer()
        this.timer.setParent(this)

        // Cansy Info Box
        const infoBox = new InfoBox()
        infoBox.setParent(this)
        infoBox.addComponent(new Transform({
            position: new Vector3(4.4 - OFFSET, 10 + OFFSET_Z, 9 - OFFSET),
            scale: new Vector3(2,2,2),
            rotation: Quaternion.Euler(0, 0, 0)
        }))


        // List of last 10 artists
        const artistList = new ArtistList(10)
        artistList.setParent(this)
        artistList.addComponent(new Transform({
            position: new Vector3(6.5 - OFFSET, 12 + OFFSET_Z, 11.5 - OFFSET),
            scale: new Vector3(2,2,2),
            rotation: Quaternion.Euler(0, 0, 0)
        }))

        // Color Picker
        const colorPickerBoard = new ColorPickerBoard(8, 2)
        colorPickerBoard.setParent(this)
        colorPickerBoard.addComponent(new Transform({
            position: new Vector3(6 - OFFSET, 10 + OFFSET_Z, 2 - OFFSET),
            scale: new Vector3(0.3,0.3,0.3),
            rotation: Quaternion.Euler(0, 0, 0)
        }))

        // Canvas
        this.canvas = new Canvas(16, 16, this.timer, artistList)
        this.canvas.setParent(this)
        this.canvas.addComponent(new Transform({
            position: new Vector3(10 - OFFSET,9 + OFFSET_Z,1 - OFFSET),
            scale: new Vector3(0.5,0.5,0.5),
            rotation: Quaternion.Euler(5, -45, 0) 
        }))

        // Music
        const music = new Music()
        music.setParent(this)
        music.addComponent(new Transform({
            position: new Vector3(4.4 - OFFSET, 10 + OFFSET_Z, 7 - OFFSET),
            scale: new Vector3(2,2,2),
            rotation: Quaternion.Euler(0, -90, 0)
        }))
    



        engine.addEntity(this)
    }

    async getCooldownTimer(pubKey: string, realm: string ) {
        // call server to get cooldown for this player
        const cooldownMilliseconds = await fetchCooldownTimer(pubKey, realm)
        this.timer.startMilliseconds(cooldownMilliseconds)
    }

}