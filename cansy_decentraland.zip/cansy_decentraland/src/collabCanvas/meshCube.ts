export class MeshCube extends Entity {
    constructor() {
        super()
       
        // this.addComponent(new GLTFShape("models/MESH_CUBE_BETA.glb"))
        this.addComponent(new GLTFShape("models/MESH CUBE CUSTOM.glb"))
    }
}