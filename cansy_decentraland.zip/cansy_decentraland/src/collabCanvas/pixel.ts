import { materialManager } from "./materialManager"
import { sendDrawPixelRequest } from "../server/server";
import { Session } from "../server/session";
import { Timer } from "./timer"
import { sceneMessageBus } from "./messageBus";
import { Audio } from './audio'
import * as ui from '@dcl/ui-scene-utils'

export type PixelData = {
    pubKey: string;
    hasConnectedWeb3: boolean;
    displayName: string;
    realm: string;
    color: string;
    x: number;
    y: number;
    timestamp: {
        _seconds: 0,
        _nanoseconds: 0
    };
  };
  

export class Pixel extends Entity {

    position: {x: number, y: number}
    color: string = 'white'
    scale: number = 1
    border: number = 0
    timer: Timer
    audio: Audio = Audio.getInstance()

    constructor(planeShape: PlaneShape, x: number, y: number, timer: Timer, color?: string) {
        super()

        this.color = color || 'white'
        this.position = {x,y}
        this.timer = timer

        // this.addComponent(new PlaneShape())
        this.addComponent(planeShape)
        this.addComponent(new Transform({
            position: new Vector3(this.scale * x + this.border, this.scale * y + this.border, 0),
            scale: new Vector3(this.scale,this.scale,this.scale)
        }))
        this.addComponent(materialManager.getMaterialByName(this.color))
        

        // on hover
        this.addComponent(
            new OnPointerHoverEnter(() => {
                // if(!this.timer.active)
                this.audio.playSilentClick2()
                this.previewColor(materialManager.getActiveColor())
            })
        )

        // on hover exit
        this.addComponent(
            new OnPointerHoverExit(() => {
                // if(!this.timer.active)
                this.previewColor(this.color)
            })
        )

        // on click
        this.addComponent(
            new OnPointerDown(() => {
                log("click", this.position)

                if (this.timer.active) {
                    new ui.LoadingIcon(2, 0, 40, 2)
                } else {
                    
                    this.audio.playSilentClick()

                    const activeColor = materialManager.getActiveColor()
                    // if same color do nothing so placement is not wasted
                    if (activeColor != this.color) {
                        this.playerPaintColor(activeColor)
                    }
                }
            })
        )
    }

    // preview color does not change the this.color state
    // only the matrial to ensure change is temporary
    previewColor(color:string) {
        // const activeColor = materialManager.getActiveColor()
        const material = materialManager.getMaterialByName(color) 
        this.addComponentOrReplace(material)
    }

    // changes color permanent
    setColor(color:string) {
        this.color = color
        const material = materialManager.getMaterialByName(color) 
        this.addComponentOrReplace(material)
    }

    // Sends a request to the server to check if player has no cooldown
    // if yes, a new pixel will be created on server and then sent to player
    private async playerPaintColor(color:string) {
        const sessionInstance = Session.getInstance()
        const user =  sessionInstance.getUserData()
        const realm = await sessionInstance.getRealm()
        const response = await sendDrawPixelRequest(
                                color, 
                                this.position.x, 
                                this.position.y, 
                                user.hasConnectedWeb3,
                                user.userId,
                                user.displayName,
                                realm?.displayName as string,
                                sessionInstance.getId())

        log(response.message)
        log("cooldown:", response.cooldown)

        const previousColor = this.color
        this.setColor(color)

        if(response.success) {
            const pixelData: PixelData = {
                pubKey: user.userId,
                hasConnectedWeb3: user.hasConnectedWeb3,
                displayName: user.displayName,
                realm: realm?.displayName as string,
                color: color,
                x: this.position.x,
                y: this.position.y,
                timestamp: { 
                    _seconds: 0,
                    _nanoseconds: 0
                }
                // Firebase Timestampformat…
                // {seconds: Math.floor(Date.now() / 1000),
                // nanoseconds: Math.floor(Math.random() * 1000000000)};
            }
            sceneMessageBus.emit("NewPixel", pixelData)

        } else {
            this.setColor(previousColor)
        }

        // display cooldown timer
        this.timer.startMilliseconds(response.cooldown)

    }

    
}