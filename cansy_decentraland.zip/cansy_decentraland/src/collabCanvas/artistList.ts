import { PixelData } from "./pixel"

type Artist = {
    displayName: string
    pubKey: string
    hasConnectedWeb3: boolean
    color: string
}

export class ArtistList extends Entity {
    displayList: string = ""
    artists: Artist[]
    length: number
    realm: string = ""

    constructor(length: number) {
        super()
        this.artists = new Array(length)
        this.length = length

        const text = new TextShape("")
        text.fontSize = 2
        text.hTextAlign = 'left'
        this.addComponent(text)
    }

    updateListByPixelHistory(pixelHistory: PixelData[]) {
        this.artists = pixelHistory.slice(0, this.length).map(pixelData => ({
            displayName: pixelData.displayName,
            pubKey: pixelData.pubKey,
            hasConnectedWeb3: pixelData.hasConnectedWeb3,
            color: pixelData.color
        }))
        this.realm = pixelHistory[0].realm
        this.updateDisplay()
    }

    updateDisplay() {
        let newString = "Recent Artists " + this.realm + "\n\n"

        for (const artist of this.artists) {
            newString += this.getCorrectString(artist) // + " " + artist.color
            newString += "\n"
        }

        this.getComponent(TextShape).value = newString
    }

    getCorrectString(artist: Artist): string {
        if (!artist.hasConnectedWeb3)
            return "anonymous"
        if (artist.displayName === "")
            return artist.pubKey.substr(0,7)

        return artist.displayName
    }

    addNewPixel(pixelData: PixelData) {
        this.addItem({
            displayName: pixelData.displayName,
            pubKey: pixelData.pubKey,
            hasConnectedWeb3: pixelData.hasConnectedWeb3,
            color: pixelData.color
        })
    }

    addItem(newArtist: Artist) {
        this.artists.unshift(newArtist);
        if (this.artists.length > 10) {
            this.artists.pop(); // Remove the last item
        }
        this.updateDisplay();
    }
    
}
