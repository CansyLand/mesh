import { Audio } from './audio'
import { materialManager } from "./materialManager"
import * as ui from '@dcl/ui-scene-utils'
 
export class InfoBox extends Entity {
    audio: Audio = Audio.getInstance()
    // text: TextShape
    prompt: any
    open: boolean = false



    constructor() {
        super()

        // this.text = new TextShape("info")
        // this.text.fontSize = 2
        // this.text.hTextAlign = 'center'
        // this.addComponent(this.text)

        // // add a shape to the entity
        // const box = new Entity()
        // box.addComponent(new BoxShape())
        // const material = materialManager.getMaterialByName("brown");
        // box.addComponent(material)
        // box.addComponent(new Transform({
        //     position: new Vector3(0,0,0.1),
        //     scale: new Vector3(0.4,0.3,0.05),
     
        // }))
        // box.setParent(this)

        this.addComponent(new GLTFShape("models/Cansy.glb"))

        // on hover
        this.addComponent(
            new OnPointerHoverEnter(() => {

                this.audio.playSilentClick2()
                // this.text.fontSize = 2
            })
        )

        // on hover exit
        this.addComponent(
            new OnPointerHoverExit(() => {
                // this.text.fontSize = 1
            })
        )

        // on click
        this.addComponent(
            new OnPointerDown(() => {
                this.audio.playSilentClick()

                if(this.open) {
                    return
                }
                this.open = true

                this.prompt = new ui.OptionPrompt(
                    'Welcome to\nThe Collective Canvas',
                    'where your creativity becomes part of a collaborative masterpiece.',
                    () => {
                        this.prompt = new ui.OptionPrompt(
                            'Welcome to\nThe Collective Canvas',
                            'Your artistic contribution matters, and by adding your brushstroke, you will forever be credited as a co-creator using your public address.',
                            () => {
                                this.prompt = new ui.OptionPrompt(
                                    'Welcome to\nThe Collective Canvas',
                                    'Join us in shaping extraordinary art pieces together.\n\n@CansyLand',
                                    () => {
                                      log(`lets paint`)
                                      this.open = false
                                    },
                                    () => {
                                        this.open = false
                                    },
                                    'ok',
                                    'close'
                                  )
                            },
                            () => {
                                this.open = false
                            },
                            'ok',
                            'close'
                          )
                    },
                    () => {
                        this.open = false
                    },
                    'ok',
                    'close'
                  )

                // let prompt = new ui.OkPrompt(
                //     ', ',
                //     () => {
                //       log(`accepted`)
                //     },
                //     'Ok',
                //     true
                //   )
            })
        )
    }
}