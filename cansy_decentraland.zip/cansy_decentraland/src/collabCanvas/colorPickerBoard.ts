import { ColorPicker } from "./colorPicker"
import { materialManager } from "./materialManager"

/**
 * This Boars holds all the available colors
 */

export class ColorPickerBoard extends Entity {
    constructor(rows: number, collumns: number/*, position: {x:number, y:number, z:number}*/) {
        super()
        this.init(rows, collumns)

        // this.addComponent(new Transform({
        //     position: new Vector3(this.scale * x + this.border, this.scale * y + this.border, 0),
        //     scale: new Vector3(this.scale,this.scale,this.scale)
        //     rotation
        // }))

    }

    init(rows: number, collumns: number) {
        let indexOfColorName = 0
        for (let i = 0; i < rows; i++) {
            for (let y = 0; y < collumns; y++) {
                // const colorPicker = new ColorPicker('lightRed', i, y)
                const colorPicker = new ColorPicker(materialManager.getColorNameByIndex(indexOfColorName), i, y)
                indexOfColorName++
                colorPicker.setParent(this)
            }
        }
    }
}