export class Cansy extends Entity {
    constructor() {
        super()

        this.addComponent(new GLTFShape("models/Cansy.glb"))
    }
}