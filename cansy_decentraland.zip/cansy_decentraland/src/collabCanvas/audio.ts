// This is singleton

export class Audio extends Entity {
    private static instance: Audio
    private loudClickAudio: AudioClip = new AudioClip("audio/click_bright_001.mp3")
    private silentClickAudio: AudioClip = new AudioClip("audio/click_bright_002.mp3")
    private clockClick: AudioClip = new AudioClip("audio/click_4.mp3")
    private silentClick2: AudioClip = new AudioClip("audio/click_3.mp3")
    private lightPing: AudioClip = new AudioClip("audio/light_ping.mp3")
  
    private constructor() {
      super()
      engine.addEntity(this)
    }
  
    public static getInstance(): Audio {
      if (!Audio.instance) {
        Audio.instance = new Audio()
      }
      return Audio.instance
    }
  
    public playSilentClick(): void {
      this.addComponentOrReplace(new AudioSource(this.silentClickAudio))
      const audioSource = this.getComponent(AudioSource)
      audioSource.playOnce()
    }
  
    public playLoudClick(): void {
      this.addComponentOrReplace(new AudioSource(this.loudClickAudio))
      const audioSource = this.getComponent(AudioSource)
      audioSource.playOnce()
    }

    public playClockClick(): void {
      this.addComponentOrReplace(new AudioSource(this.clockClick))
      const audioSource = this.getComponent(AudioSource)
      audioSource.playOnce()
    }

    public playLightPing(): void {
        this.addComponentOrReplace(new AudioSource(this.lightPing))
        const audioSource = this.getComponent(AudioSource)
        audioSource.playOnce()
    }

    public playSilentClick2(): void {
        this.addComponentOrReplace(new AudioSource(this.silentClick2))
        const audioSource = this.getComponent(AudioSource)
        audioSource.playOnce()
    }
  }
  