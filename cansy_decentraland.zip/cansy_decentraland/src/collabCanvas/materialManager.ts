class MaterialManager {
  private static instance: MaterialManager;
  private material: { [key: string]: Material };
  private activeColor: string = 'redLight';

  private constructor() {
    this.material = {
      black: new Material(),
      grayDark: new Material(),
      grayLight: new Material(),
      white: new Material(),
      blue: new Material(),
      purple: new Material(),
      redDark: new Material(),
      redLight: new Material(),
      greenDark: new Material(),
      greenLight: new Material(),
      pinkDark: new Material(),
      pinkLight: new Material(),
      brown: new Material(),
      orange: new Material(),
      cyan: new Material(),
      yellow: new Material(),
    };

    this.initMaterials();
    this.forEachMaterial((color,material) => {
      // material.metallic = 0.9
      // material.roughness = 0.9
      material.emissiveIntensity = 0.5
      //material.albedoColor
    })
  }

  public static getInstance(): MaterialManager {
    if (!MaterialManager.instance) {
      MaterialManager.instance = new MaterialManager();
    }
    return MaterialManager.instance;
  }

  private initMaterials(): void {
    this.material.black.albedoColor = Color3.FromHexString("#000000");
    // this.material.grayDark.albedoColor = Color3.FromHexString("#68605c");
    // this.material.grayLight.albedoColor = Color3.FromHexString("#b0b0b8");
    // this.material.white.albedoColor = Color3.FromHexString("#ffffff");
    // this.material.blue.albedoColor = Color3.FromHexString("#1c38ac");
    // this.material.purple.albedoColor = Color3.FromHexString("#020291");
    // this.material.redDark.albedoColor = Color3.FromHexString("#a82814");
    // this.material.redLight.albedoColor = Color3.FromHexString("#fc4848");
    // this.material.greenDark.albedoColor = Color3.FromHexString("#208800");
    // this.material.greenLight.albedoColor = Color3.FromHexString("#70f828");
    // this.material.pinkDark.albedoColor = Color3.FromHexString("#b82cd0");
    // this.material.pinkLight.albedoColor = Color3.FromHexString("#fc74ec");
    // this.material.brown.albedoColor = Color3.FromHexString("#ac581c");
    // this.material.orange.albedoColor = Color3.FromHexString("#f8a850");
    // this.material.cyan.albedoColor = Color3.FromHexString("#3cd4e4");


    const grayDark = this.hexToRgbGlow("#68605c");
    this.material.grayDark.albedoColor = new Color3(grayDark.r, grayDark.g, grayDark.b);

    const grayLight = this.hexToRgbGlow("#b0b0b8");
    this.material.grayLight.albedoColor = new Color3(grayLight.r, grayLight.g, grayLight.b);

    const white = this.hexToRgbGlow("#ffffff");
    this.material.white.albedoColor = new Color3(white.r, white.g, white.b);

    const blue = this.hexToRgbGlow("#1c38ac");
    this.material.blue.albedoColor = new Color3(blue.r, blue.g, blue.b);

    const purple = this.hexToRgbGlow("#020291");
    this.material.purple.albedoColor = new Color3(purple.r, purple.g, purple.b);

    const redDark = this.hexToRgbGlow("#a82814");
    this.material.redDark.albedoColor = new Color3(redDark.r, redDark.g, redDark.b);

    const redLight = this.hexToRgbGlow("#fc4848");
    this.material.redLight.albedoColor = new Color3(redLight.r, redLight.g, redLight.b);

    const greenDark = this.hexToRgbGlow("#208800");
    this.material.greenDark.albedoColor = new Color3(greenDark.r, greenDark.g, greenDark.b);

    const greenLight = this.hexToRgbGlow("#70f828");
    this.material.greenLight.albedoColor = new Color3(greenLight.r, greenLight.g, greenLight.b);

    const pinkDark = this.hexToRgbGlow("#b82cd0");
    this.material.pinkDark.albedoColor = new Color3(pinkDark.r, pinkDark.g, pinkDark.b);

    const pinkLight = this.hexToRgbGlow("#fc74ec");
    this.material.pinkLight.albedoColor = new Color3(pinkLight.r, pinkLight.g, pinkLight.b);

    const brown = this.hexToRgbGlow("#ac581c");
    this.material.brown.albedoColor = new Color3(brown.r, brown.g, brown.b);

    const orange = this.hexToRgbGlow("#f8a850");
    this.material.orange.albedoColor = new Color3(orange.r, orange.g, orange.b);

    const cyan = this.hexToRgbGlow("#3cd4e4");
    this.material.cyan.albedoColor = new Color3(cyan.r, cyan.g, cyan.b);

    const yellow = this.hexToRgbGlow("#f8ec20");
    this.material.yellow.albedoColor = new Color3(yellow.r, yellow.g, yellow.b);

  }

  public forEachMaterial(callback: (color: string, material: Material) => void): void {
    for (const color in this.material) {
      if (this.material.hasOwnProperty(color)) {
        const material = this.material[color];
        callback(color, material);
      }
    }
  }

  public getMaterialByName(color: string): Material {
    // Make sure the color is valid or fallback to 'white'
    let newColor = color
    if(!this.colorExist(color)) 
      newColor = 'white'
    
    // Use the index signature to access the material object with a string key
    return this.material[newColor] as Material;
  }

  public getColorNameByIndex(index: number): string {
    const keys = Object.keys(this.material);
    const colorName = keys[index];
    return colorName || 'white';
  }

  public setActiveColor(newColor:string): void {
    if(this.colorExist(newColor))
      this.activeColor = newColor
  }

  public getActiveColor(): string {
    return this.activeColor
  }

  public colorExist(color:string): boolean {
    return color && this.material.hasOwnProperty(color) ? true : false;
  }

  private hexToRgb(hexColor:string) {
    // Remove the leading '#' if present
    if (hexColor[0] == "#") {
      hexColor = hexColor.substring(1);
    }
  
    // Convert the hex color to RGB
    const r = parseInt(hexColor.substring(0, 2), 16) / 255;
    const g = parseInt(hexColor.substring(2, 4), 16) / 255;
    const b = parseInt(hexColor.substring(4, 6), 16) / 255;
  
    // Return the RGB values as an object
    return { r, g, b };
  }

  private hexToRgbGlow(hexColor:string) {
    // Remove the leading '#' if present
    if (hexColor[0] == "#") {
      hexColor = hexColor.substring(1);
    }
  
    // Convert the hex color to RGB
    let r = parseInt(hexColor.substring(0, 2), 16) / 255;
    let g = parseInt(hexColor.substring(2, 4), 16) / 255;
    let b = parseInt(hexColor.substring(4, 6), 16) / 255;

    // Add Glow
    const glow = 2
    r *= glow
    g *= glow
    b *= glow
  
    // Return the RGB values as an object
    return { r, g, b };
  }
  
}

export const materialManager = MaterialManager.getInstance();


