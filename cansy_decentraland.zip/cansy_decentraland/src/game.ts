import { getUserData } from "@decentraland/Identity";
import { CollabCanvasControllCenter } from "./collabCanvas/collabCanvasControllCenter";
import { Session } from "./server/session";


const collabCanvasControllCenter = new CollabCanvasControllCenter()
collabCanvasControllCenter.addComponent(new Transform({
  position: new Vector3(8,0,8),
  rotation: Quaternion.Euler(0, 0, 0) // <-- Here you can rotate everything
}))




/**
* The Collective Canvas: A Collaborative Masterpiece
*
* Step into the MESH exhibition cube, where a vibrant and dynamic canvas awaits 
* your brushstrokes. Experience the interactive artboard that invites visitors 
* to collaborate and paint, transforming them into participating artists themselves.
* 
* After the exhibition concludes, these artworks will be rendered into videos that 
* capture the creative journey over time. As a testament to their artistic contribution, 
* participants will be credited using their public addresses, forever recognized as 
* co-creators of these extraordinary art pieces.
* 
* This groundbreaking experience marks the first of its kind, as the community unites 
* inside Decentraland to collectively create art.
* 
* @CansyLand
 */







//******************************************************* */
// Session makes sure player is actually in scene when placing pixel
const sessionInstance = Session.getInstance()

executeTask(async () => {
  log("GAME ON")
  // Start
  // new session, so server knows you are actualy on the parcel
  onEnterSceneObservable.add(async (player) => {
    log("PLAYER ENTERED SCENE")
    await sessionInstance.init();
    log("NEW SESSION INSTANCE")
    log("player entered scene: ", player.userId)
    const sessionUserData = sessionInstance.getUserData()//?.userId
    if (player.userId === sessionUserData.userId) {
      log("I entered the scene!")
      await sessionInstance.startSession();

  
      // const playerRealm = await getCurrentRealm()
      const playerRealm = await sessionInstance.getRealm()
      
      // Displays timer: how long player has to wait to place next pixel
      collabCanvasControllCenter.getCooldownTimer(
        sessionUserData.userId, 
        playerRealm?.displayName || "")
    }

    // Load and draw PixelCanvas History
    collabCanvasControllCenter.canvas.drawPixelHistory()
  })

  // Stop
  // Ends session on server if player leaves scene
  onLeaveSceneObservable.add(async (player) => {
    log("player left scene: ", player.userId)
    if (player.userId === sessionInstance.getUserData()?.userId) {
      log("I left the scene!")
      await sessionInstance.stopSession()
    }
  })
})
