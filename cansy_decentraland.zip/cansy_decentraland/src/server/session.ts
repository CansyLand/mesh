
// Session uses singleton pattern

// Usage example:

// const singletonInstance = Session.getInstance();
// singletonInstance.someMethod();

// const anotherInstance = Session.getInstance();
// anotherInstance.someMethod();

// // Both instances are the same
// log(singletonInstance === anotherInstance); // true



import { getUserData, UserData } from "@decentraland/Identity"
import { getCurrentRealm, Realm } from "@decentraland/EnvironmentAPI"
import { AppConfig } from "./config"

const URL = AppConfig.apiUrl


interface GameUserData extends UserData {
  popTabs: number;
  lastPopTabClaim: {
    _seconds: number,
    _nanoseconds: number
  };
}

export class Session {
    
    private id: string = "0"
    private userData!: GameUserData /*= {
      publicKey: "",
      displayName: "",
      popTabs: 0,
      lastPopTabClaim: 0,
      hasConnectedWeb3: false,
      userId: "",
      version: 0,
      avatar: {
        bodyShape: "",
        skinColor: "",
        hairColor: "",
        eyeColor: "",
        wearables: [],
        snapshots: {
          face: "",
          face256: "",
          face128: "",
          body: ""
        }
      }
    }*/
    private realm: Realm | undefined
    private static instance: Session;
    initialized: boolean = false

  
    private constructor() {      
      // executeTask(async () => {
      //   const userData = await getUserData();
      //   if (userData) {
      //     this.userData = {
      //       ...userData,
      //       popTabs: 0,
      //       lastPopTabClaim: 0
      //     };
      //   }
      // })
    }
  
    public static getInstance(): Session {
      if (!Session.instance) {
        Session.instance = new Session();
      }
      return Session.instance;
    }

    public async init(): Promise<void> {
      if (!this.userData) {
        const userData = await getUserData(); // data from DCL
        if (userData) {
          this.userData = {
            ...userData,
            popTabs: 0,
            lastPopTabClaim: {
              _seconds: 0,
              _nanoseconds: 0
            },
          };
        }
      }
    }

    async getRealm(): Promise<Realm | undefined> {
      if (!this.realm) {
        const playersRealm = await getCurrentRealm()
        if (playersRealm) {
          this.realm = playersRealm
          return this.realm
        } else {
          log("Error: Could not load realm")
        }
        
      } else {
        return this.realm
      }
    }

    getId(): string {
      return this.id;
    }

    getUserData(): GameUserData {
      return this.userData;
    }

    updateUserDataScore(score: number): void {
      this.userData.popTabs += score
    }

    // Start the session by fetching the user data and sending it to the server
    async startSession(): Promise<void>  {

      const playerRealm = await getCurrentRealm()
    
      const credentials = {
        publicKey: this.userData?.publicKey,
        displayName: this.userData?.displayName,
        bodyShape: this.userData?.avatar.bodyShape == "urn:decentraland:off-chain:base-avatars:BaseFemale"? 0 : 1,
        realmId: playerRealm?.displayName 
      }
    
      // Send user credentials to the server in a POST request
      // try {
        const response = await fetch(URL + "/enterScene", {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(credentials)
        });
    
        if (!response.ok) {
          throw new Error(`HTTP error starting Session! Status: ${response.status}`);
        }
    
        // Handle the server response, storing the sessionId and playerData
        const { sessionId, playerData } = await response.json();
        this.id = sessionId
        this.userData = {
          ...this.userData,
          ...playerData,
        };
        
        this.initialized = true
        
        log("MyUserData")
        log(this.userData)

        log("Connect server POST request response:", this.userData);
    
      // } catch (error) {
      //   log("Connect server Error sending POST request:", error);
      // }
    }

    // Stop the session by sending a POST request to the server at "/leaveScene"
    async stopSession(): Promise<void> {
      try {
        const response = await fetch(URL + "/leaveScene", {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          // Prepare the request body with the sessionId
          body: JSON.stringify({sessionId: this.id})
        });
    
        // Handle the server response, logging the result
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
    
        const data = await response.json();
        log("Connect server POST request response:", data);
    
      } catch (error) {
        log("Connect server Error sending POST request:", error);

      }
    }
  }
