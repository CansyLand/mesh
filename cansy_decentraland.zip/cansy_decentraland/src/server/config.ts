
export const AppConfig = {
    // apiUrl: "http://127.0.0.1:5001/cansy-decentraland/europe-west1/collabcanvas"
    apiUrl: "https://europe-west1-cansy-decentraland.cloudfunctions.net/collabcanvas"
    // Add other configuration constants and settings here
  };
  