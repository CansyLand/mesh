import { AppConfig } from "./config"
import { PixelData } from "../collabCanvas/pixel";

const URL = AppConfig.apiUrl


/**
 * Fetches the cooldown timer from the server for a specific player and realm.
 *
 * @returns {Promise<number>} A promise that resolves to the cooldown timer value in milliseconds.
 * @throws {Error} If there is an HTTP error or an error during the fetching process.
 */
export async function fetchCooldownTimer(pubKey: string, realm: string): Promise<number> {
        try {
          const response = await fetch(`${URL}/cooldownTimer?pubKey=${encodeURIComponent(pubKey)}&realm=${encodeURIComponent(realm)}`);
          
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          
          const data = await response.json();
          return data.cooldown;
        } catch (error) {
          log('Error fetching cooldownTimer:', error);
          throw error;
        }
      }

/**
 * Draws a pixel on the canvas.
 *
 * @returns {Promise<{cooldown: number, success: boolean, message: string}>} A promise that resolves to an object containing the cooldown time, success status, and a message.
 * @throws {Error} If the session is not active or there is an error during the pixel drawing process.
 */
export async function sendDrawPixelRequest(color: string, x: number, y: number, hasConnectedWeb3: boolean, pubKey: string, displayName: string, realm: string, sessionId: string): Promise<{ cooldown: number, message: string, success: boolean }> {
        try {
          const response = await fetch(`${URL}/drawPixel`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify({ color, x, y, pubKey, hasConnectedWeb3, displayName, realm, sessionId })
          });
      
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
      
          return await response.json();
        } catch (error) {
          log('Error sending drawPixel request:', error);
          throw error;
        }
      }

/**
 * Fetches the pixel history from the server for a specific realm.
 *
 * @param {string} realm - The realm for which to fetch the pixel history.
 * @param {number} limit - Limit is fixed to 169 serverside at the moment The maximum number of pixels to retrieve.
 * @returns {Promise<Array<Pixel>>} A promise that resolves to an array of pixel objects representing the pixel history.
 * @throws {Error} If there is an HTTP error or an error during the fetching process.
 */
export async function fetchPixelHistory(realm: string, limit: number = 0): Promise<Array<PixelData>> {
        try {
            const response = await fetch(`${URL}/pixelHistory?realm=${encodeURIComponent(realm)}&limit=${limit}`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            
            const data = await response.json();
            return data;
        } catch (error) {
            log("Error fetching pixel history:", error);
        throw error;
        }
    }
  